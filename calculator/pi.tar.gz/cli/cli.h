#ifndef CLI
#define CLI
/// CLI colors
#endif
